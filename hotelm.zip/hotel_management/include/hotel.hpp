#pragma once
#include <memory>
#include <optional>
#include <string>
#include <vector>

enum class RoomType { Single, Double, Deluxe, Suite };
enum class BookingStatus { Booked, CheckedIn, CheckedOut, Cancelled };

constexpr double GST_RATE = 0.12;

// ---- date helpers (a date is stored as a day number) ----
int daysFromCivil(int y, int m, int d);
std::string dayToString(int day);
std::optional<int> parseDate(const std::string& s);  // "YYYY-MM-DD"
int todayDay();

// ---- rooms ----
class Room {
public:
    explicit Room(int number) : number_(number) {}
    virtual ~Room() = default;
    int number() const { return number_; }
    virtual RoomType type() const = 0;
    virtual std::string typeName() const = 0;
    virtual double pricePerNight() const = 0;
    virtual int capacity() const = 0;
private:
    int number_;
};

class SingleRoom : public Room {
public:
    using Room::Room;
    RoomType type() const override { return RoomType::Single; }
    std::string typeName() const override { return "Single"; }
    double pricePerNight() const override { return 1500; }
    int capacity() const override { return 1; }
};
class DoubleRoom : public Room {
public:
    using Room::Room;
    RoomType type() const override { return RoomType::Double; }
    std::string typeName() const override { return "Double"; }
    double pricePerNight() const override { return 2500; }
    int capacity() const override { return 2; }
};
class DeluxeRoom : public Room {
public:
    using Room::Room;
    RoomType type() const override { return RoomType::Deluxe; }
    std::string typeName() const override { return "Deluxe"; }
    double pricePerNight() const override { return 4000; }
    int capacity() const override { return 3; }
};
class SuiteRoom : public Room {
public:
    using Room::Room;
    RoomType type() const override { return RoomType::Suite; }
    std::string typeName() const override { return "Suite"; }
    double pricePerNight() const override { return 7000; }
    int capacity() const override { return 4; }
};

std::unique_ptr<Room> makeRoom(RoomType type, int number);

// ---- records ----
struct Guest {
    int id;
    std::string name;
    std::string phone;
};

struct Booking {
    int id;
    int guestId;
    int roomNo;
    int startDay;
    int nights;
    BookingStatus status;
    double services;  // food, laundry, etc.
    int endDay() const { return startDay + nights; }
};

const char* statusName(BookingStatus s);

// ---- the hotel ----
class Hotel {
public:
    explicit Hotel(std::string dataDir = "data") : dir_(std::move(dataDir)) {}

    bool load();        // storage.cpp
    bool save() const;  // storage.cpp

    int registerGuest(std::string name, std::string phone);
    const Guest* findGuest(int id) const;
    std::vector<const Guest*> searchGuests(const std::string& name) const;

    const std::vector<std::unique_ptr<Room>>& rooms() const { return rooms_; }
    const Room* findRoom(int number) const;
    bool isOccupiedToday(int roomNo) const;
    std::vector<const Room*> availableRooms(int startDay, int nights,
                                            std::optional<RoomType> filter,
                                            double maxPrice) const;

    int book(int guestId, int roomNo, int startDay, int nights, std::string& err);
    bool checkIn(int bookingId, std::string& err);
    bool checkOut(int bookingId, std::string& invoice, std::string& err);
    bool cancel(int bookingId, std::string& err);
    bool addService(int bookingId, double amount, std::string& err);

    const Booking* findBooking(int id) const;
    std::vector<const Booking*> bookingsFor(int guestId) const;
    std::string invoiceFor(const Booking& b) const;

private:
    Booking* findBookingMut(int id);
    bool roomFree(int roomNo, int startDay, int endDay) const;
    void resetDefaults();

    std::string dir_;
    std::vector<std::unique_ptr<Room>> rooms_;
    std::vector<Guest> guests_;
    std::vector<Booking> bookings_;
    int nextGuestId_ = 1;
    int nextBookingId_ = 1;
};
