#include <iomanip>
#include <iostream>
#include <stdexcept>

#include "hotel.hpp"

// ---------- input helpers ----------
static std::string readLine(const std::string& prompt) {
    std::cout << prompt;
    std::string s;
    if (!std::getline(std::cin, s)) throw std::runtime_error("end of input");
    size_t a = s.find_first_not_of(" \t\r"), b = s.find_last_not_of(" \t\r");
    return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}

static int readInt(const std::string& prompt, int lo, int hi) {
    while (true) {
        std::string s = readLine(prompt);
        try {
            size_t p;
            int v = std::stoi(s, &p);
            if (p == s.size() && v >= lo && v <= hi) return v;
        } catch (...) {}
        std::cout << "  Please enter a number from " << lo << " to " << hi << ".\n";
    }
}

static double readAmount(const std::string& prompt) {
    while (true) {
        std::string s = readLine(prompt);
        try {
            size_t p;
            double v = std::stod(s, &p);
            if (p == s.size() && v > 0) return v;
        } catch (...) {}
        std::cout << "  Please enter a positive amount.\n";
    }
}

static int readDay(const std::string& prompt) {
    while (true) {
        if (auto d = parseDate(readLine(prompt))) return *d;
        std::cout << "  Use a valid date as YYYY-MM-DD.\n";
    }
}

static std::string readNonEmpty(const std::string& prompt) {
    while (true) {
        std::string s = readLine(prompt);
        if (!s.empty()) return s;
        std::cout << "  This cannot be empty.\n";
    }
}

// ---------- display helpers ----------
static void printRooms(const std::vector<const Room*>& rooms) {
    if (rooms.empty()) { std::cout << "  No rooms found.\n"; return; }
    std::cout << "  Room  Type     Guests  Price/night\n";
    for (const Room* r : rooms)
        std::cout << "  " << std::left << std::setw(6) << r->number() << std::setw(9) << r->typeName()
                  << std::setw(8) << r->capacity() << "Rs. " << static_cast<int>(r->pricePerNight()) << "\n";
}

static void printBooking(const Hotel& h, const Booking& b) {
    const Guest* g = h.findGuest(b.guestId);
    std::cout << "  Booking #" << b.id << " | " << (g ? g->name : "?") << " | Room " << b.roomNo << " | "
              << dayToString(b.startDay) << " to " << dayToString(b.endDay()) << " | "
              << statusName(b.status) << "\n";
}

static std::optional<RoomType> askType() {
    std::cout << "  Room type: 1 Single  2 Double  3 Deluxe  4 Suite  0 Any\n";
    int t = readInt("  Choice: ", 0, 4);
    if (t == 0) return std::nullopt;
    return static_cast<RoomType>(t - 1);
}

static void report(bool ok, const std::string& err, Hotel& h) {
    if (ok) { h.save(); std::cout << "  Done.\n"; }
    else std::cout << "  Error: " << err << "\n";
}

// ---------- menu actions ----------
static void registerGuest(Hotel& h) {
    std::string name = readNonEmpty("  Guest name: ");
    std::string phone = readNonEmpty("  Phone: ");
    int id = h.registerGuest(name, phone);
    h.save();
    std::cout << "  Registered. Your guest ID is " << id << ".\n";
}

static void showAvailable(Hotel& h) {
    int start = readDay("  Check-in date (YYYY-MM-DD): ");
    int nights = readInt("  Nights: ", 1, 365);
    auto type = askType();
    int maxP = readInt("  Max price per night (0 = no limit): ", 0, 1000000);
    printRooms(h.availableRooms(start, nights, type, maxP));
}

static void bookRoom(Hotel& h) {
    int gid = readInt("  Guest ID: ", 1, 1000000);
    if (!h.findGuest(gid)) { std::cout << "  No guest with that ID. Register first (option 1).\n"; return; }
    int start = readDay("  Check-in date (YYYY-MM-DD): ");
    int nights = readInt("  Nights: ", 1, 365);
    auto type = askType();
    auto rooms = h.availableRooms(start, nights, type, 0);
    printRooms(rooms);
    if (rooms.empty()) return;
    int room = readInt("  Room number to book (0 to cancel): ", 0, 100000);
    if (room == 0) return;
    std::string err;
    int id = h.book(gid, room, start, nights, err);
    if (id < 0) { std::cout << "  Error: " << err << "\n"; return; }
    h.save();
    std::cout << "  Booked! Your booking ID is " << id << ".\n";
}

static void checkIn(Hotel& h) {
    std::string err;
    report(h.checkIn(readInt("  Booking ID: ", 1, 1000000), err), err, h);
}

static void checkOut(Hotel& h) {
    std::string err, invoice;
    bool ok = h.checkOut(readInt("  Booking ID: ", 1, 1000000), invoice, err);
    report(ok, err, h);
    if (ok) std::cout << invoice;
}

static void cancelBooking(Hotel& h) {
    std::string err;
    report(h.cancel(readInt("  Booking ID: ", 1, 1000000), err), err, h);
}

static void addService(Hotel& h) {
    int id = readInt("  Booking ID: ", 1, 1000000);
    double amt = readAmount("  Service amount (Rs.): ");
    std::string err;
    report(h.addService(id, amt, err), err, h);
}

static void findGuest(Hotel& h) {
    std::string key = readNonEmpty("  Guest ID or part of name: ");
    std::vector<const Guest*> found;
    try {
        size_t p;
        int id = std::stoi(key, &p);
        if (p == key.size()) { if (auto* g = h.findGuest(id)) found.push_back(g); }
    } catch (...) { found = h.searchGuests(key); }
    if (found.empty()) { std::cout << "  No guest found.\n"; return; }
    for (const Guest* g : found) {
        std::cout << "  Guest " << g->id << ": " << g->name << " (" << g->phone << ")\n";
        auto bs = h.bookingsFor(g->id);
        if (bs.empty()) std::cout << "    No bookings.\n";
        for (const Booking* b : bs) { std::cout << "  "; printBooking(h, *b); }
    }
}

static void listRooms(Hotel& h) {
    std::cout << "  Room  Type     Guests  Price/night  Now\n";
    for (const auto& r : h.rooms())
        std::cout << "  " << std::left << std::setw(6) << r->number() << std::setw(9) << r->typeName()
                  << std::setw(8) << r->capacity() << std::setw(13)
                  << ("Rs. " + std::to_string(static_cast<int>(r->pricePerNight())))
                  << (h.isOccupiedToday(r->number()) ? "Occupied" : "Free") << "\n";
}

int main() {
    Hotel hotel("data");
    if (!hotel.load()) { std::cerr << "Could not read or write the data folder.\n"; return 1; }

    std::cout << "=== Hotel Management System ===\n";
    try {
        while (true) {
            std::cout << "\n 1 Register guest      2 Check availability   3 Book a room\n"
                         " 4 Check in            5 Check out + invoice  6 Cancel booking\n"
                         " 7 Add service charge  8 Find guest/bookings  9 List all rooms\n"
                         " 0 Exit\n";
            switch (readInt("Choose: ", 0, 9)) {
                case 1: registerGuest(hotel); break;
                case 2: showAvailable(hotel); break;
                case 3: bookRoom(hotel); break;
                case 4: checkIn(hotel); break;
                case 5: checkOut(hotel); break;
                case 6: cancelBooking(hotel); break;
                case 7: addService(hotel); break;
                case 8: findGuest(hotel); break;
                case 9: listRooms(hotel); break;
                case 0: hotel.save(); std::cout << "Goodbye.\n"; return 0;
            }
        }
    } catch (const std::runtime_error&) {
        hotel.save();
        std::cout << "\nGoodbye.\n";
    }
    return 0;
}
